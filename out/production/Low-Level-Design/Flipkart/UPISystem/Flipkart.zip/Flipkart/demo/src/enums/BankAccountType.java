package Interviews.Flipkart.demo.src.enums;

public enum BankAccountType {
    PRIMARY, SECONDARY;
}
